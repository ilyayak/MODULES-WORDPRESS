(function ($) {
    $(document).ready(function () {
        /*
        TODO:
        Add link to Optimole when "deactivate" link is clicked / uninstalled #356
        https://github.com/rosell-dk/webp-express/issues/356

        var linkEl = $('tr[data-plugin^="webp-express/"] span.deactivate a');
        //console.log(el);
        linkEl.on('click', function (e) {
			//e.preventDefault();
			//e.stopPropagation();
            //alert('NO!');
        });
        */
    });
})(jQuery);
